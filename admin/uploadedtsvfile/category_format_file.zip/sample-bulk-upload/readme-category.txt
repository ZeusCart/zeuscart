   1. Open the .tsv file in Excel	
   1. Don't Modify Or Delete The First Line Of Category TVS File
   2. Modify The Dummy Category Details From The Second Line Of Category TSV File
   3. Append The Category Details In The Given Format
   4. Enter the Category Ids Correctly Given in the Category Details TSV File
   5. Enter the Type of Category Correctly as Parent or Child (lower case only) in the Category TSV File
   6. Enter the Category_Parent_Id as Zero(0) for Main Category in the Category TSV File
   7. Save the file in the same .tsv format.	
